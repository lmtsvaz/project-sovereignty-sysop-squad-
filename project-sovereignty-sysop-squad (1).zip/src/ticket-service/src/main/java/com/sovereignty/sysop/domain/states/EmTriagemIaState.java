package com.sovereignty.sysop.domain.states;

import com.sovereignty.sysop.domain.model.Ticket;

public class EmTriagemIaState implements TicketState {
    @Override public String getNomeEstado() { return "EM_TRIAGEM_IA"; }

    @Override
    public void concluirTriagemIa(Ticket ticket, String categoria, String severidade) {
        throw new IllegalStateException("Triagem de IA já concluída.");
    }

    @Override
    public void ativarContingencia(Ticket ticket) {
        ticket.alterarEstado(new ContingenciaState());
    }

    @Override
    public void atribuirConsultor(Ticket ticket, String consultorId) {
        ticket.vincularConsultor(consultorId);
        ticket.alterarEstado(new AguardandoConsultorState());
    }

    @Override
    public void iniciarAtendimento(Ticket ticket) {
        throw new IllegalStateException("Atribua um consultor antes de iniciar o atendimento.");
    }

    @Override
    public void resolver(Ticket ticket, String solucaoAplicada) {
        throw new IllegalStateException("Ticket em triagem não pode ser resolvido sem atendimento.");
    }
}
