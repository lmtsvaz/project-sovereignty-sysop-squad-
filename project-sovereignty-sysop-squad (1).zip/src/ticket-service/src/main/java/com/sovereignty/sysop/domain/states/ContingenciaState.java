package com.sovereignty.sysop.domain.states;

import com.sovereignty.sysop.domain.model.Ticket;

public class ContingenciaState implements TicketState {
    @Override public String getNomeEstado() { return "CONTINGENCIA_ROUND_ROBIN"; }

    @Override
    public void concluirTriagemIa(Ticket ticket, String categoria, String severidade) {
        throw new IllegalStateException("Ticket em modo de contingência ignora triagem pesada de IA.");
    }

    @Override
    public void ativarContingencia(Ticket ticket) {
        // Já está em contingência
    }

    @Override
    public void atribuirConsultor(Ticket ticket, String consultorId) {
        ticket.vincularConsultor(consultorId);
        ticket.alterarEstado(new AguardandoConsultorState());
    }

    @Override
    public void iniciarAtendimento(Ticket ticket) {
        throw new IllegalStateException("Aguardando atribuição da fila regional.");
    }

    @Override
    public void resolver(Ticket ticket, String solucaoAplicada) {
        throw new IllegalStateException("Ticket em contingência precisa ser atendido antes de encerrar.");
    }
}
