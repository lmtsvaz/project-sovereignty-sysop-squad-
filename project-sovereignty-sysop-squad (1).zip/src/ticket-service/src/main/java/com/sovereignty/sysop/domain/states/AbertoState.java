package com.sovereignty.sysop.domain.states;

import com.sovereignty.sysop.domain.model.Ticket;

public class AbertoState implements TicketState {
    @Override public String getNomeEstado() { return "ABERTO"; }

    @Override
    public void concluirTriagemIa(Ticket ticket, String categoria, String severidade) {
        ticket.definirClassificacao(categoria, severidade);
        ticket.alterarEstado(new EmTriagemIaState());
    }

    @Override
    public void ativarContingencia(Ticket ticket) {
        ticket.alterarEstado(new ContingenciaState());
    }

    @Override
    public void atribuirConsultor(Ticket ticket, String consultorId) {
        throw new IllegalStateException("Ticket aberto deve passar pela triagem ou contingência antes da atribuição.");
    }

    @Override
    public void iniciarAtendimento(Ticket ticket) {
        throw new IllegalStateException("Não é possível iniciar atendimento de um ticket aberto.");
    }

    @Override
    public void resolver(Ticket ticket, String solucaoAplicada) {
        throw new IllegalStateException("Ticket aberto não pode ser resolvido diretamente.");
    }
}
