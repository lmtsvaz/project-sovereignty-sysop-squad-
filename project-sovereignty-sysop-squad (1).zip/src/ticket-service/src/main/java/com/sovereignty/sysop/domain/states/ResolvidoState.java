package com.sovereignty.sysop.domain.states;

import com.sovereignty.sysop.domain.model.Ticket;

public class ResolvidoState implements TicketState {
    @Override public String getNomeEstado() { return "RESOLVIDO"; }

    @Override
    public void concluirTriagemIa(Ticket ticket, String categoria, String severidade) {
        throw new IllegalStateException("Ticket encerrado não permite alterações.");
    }

    @Override
    public void ativarContingencia(Ticket ticket) {
        throw new IllegalStateException("Ticket encerrado não permite alterações.");
    }

    @Override
    public void atribuirConsultor(Ticket ticket, String consultorId) {
        throw new IllegalStateException("Ticket encerrado não permite alterações.");
    }

    @Override
    public void iniciarAtendimento(Ticket ticket) {
        throw new IllegalStateException("Ticket encerrado não permite alterações.");
    }

    @Override
    public void resolver(Ticket ticket, String solucaoAplicada) {
        throw new IllegalStateException("Ticket já foi resolvido.");
    }
}
