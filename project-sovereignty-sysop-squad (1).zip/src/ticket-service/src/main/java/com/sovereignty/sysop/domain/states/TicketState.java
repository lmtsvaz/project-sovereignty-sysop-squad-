package com.sovereignty.sysop.domain.states;

import com.sovereignty.sysop.domain.model.Ticket;

public interface TicketState {
    String getNomeEstado();
    void concluirTriagemIa(Ticket ticket, String categoria, String severidade);
    void ativarContingencia(Ticket ticket);
    void atribuirConsultor(Ticket ticket, String consultorId);
    void iniciarAtendimento(Ticket ticket);
    void resolver(Ticket ticket, String solucaoAplicada);
}
