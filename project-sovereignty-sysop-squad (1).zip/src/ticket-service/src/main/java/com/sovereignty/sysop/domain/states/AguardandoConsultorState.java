package com.sovereignty.sysop.domain.states;

import com.sovereignty.sysop.domain.model.Ticket;

public class AguardandoConsultorState implements TicketState {
    @Override public String getNomeEstado() { return "AGUARDANDO_CONSULTOR"; }

    @Override
    public void concluirTriagemIa(Ticket ticket, String categoria, String severidade) {
        throw new IllegalStateException("Ticket já possui consultor atribuído.");
    }

    @Override
    public void ativarContingencia(Ticket ticket) {
        throw new IllegalStateException("Consultor já atribuído; contingência não aplicável.");
    }

    @Override
    public void atribuirConsultor(Ticket ticket, String consultorId) {
        ticket.vincularConsultor(consultorId);
    }

    @Override
    public void iniciarAtendimento(Ticket ticket) {
        ticket.alterarEstado(new EmAtendimentoState());
    }

    @Override
    public void resolver(Ticket ticket, String solucaoAplicada) {
        throw new IllegalStateException("Inicie o atendimento antes de resolver o ticket.");
    }
}
