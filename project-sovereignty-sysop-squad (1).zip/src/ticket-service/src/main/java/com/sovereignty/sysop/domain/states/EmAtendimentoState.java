package com.sovereignty.sysop.domain.states;

import com.sovereignty.sysop.domain.model.Ticket;

public class EmAtendimentoState implements TicketState {
    @Override public String getNomeEstado() { return "EM_ATENDIMENTO"; }

    @Override
    public void concluirTriagemIa(Ticket ticket, String categoria, String severidade) {
        throw new IllegalStateException("Ticket já está em atendimento.");
    }

    @Override
    public void ativarContingencia(Ticket ticket) {
        throw new IllegalStateException("Ticket já está em atendimento.");
    }

    @Override
    public void atribuirConsultor(Ticket ticket, String consultorId) {
        ticket.vincularConsultor(consultorId);
    }

    @Override
    public void iniciarAtendimento(Ticket ticket) {
        // Já está em atendimento
    }

    @Override
    public void resolver(Ticket ticket, String solucaoAplicada) {
        ticket.registrarSolucao(solucaoAplicada);
        ticket.alterarEstado(new ResolvidoState());
    }
}
